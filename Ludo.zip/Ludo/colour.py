class Colour:

    COLOURS = [
        "RED",
        "YELLOW",
        "GREEN",
        "BLUE"
    ]

    def __init__(self):
        pass
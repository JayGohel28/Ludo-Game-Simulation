# Ludo Game in Python

A complete Ludo board game implemented in Python using Pygame.

## Features

- 4-player Ludo game with graphical interface
- Dice rolling with random numbers
- Piece movement along the board
- Capturing opponent pieces
- Private paths to the center
- Win condition detection
- Turn-based gameplay

## Requirements

- Python 3.x
- Pygame

## Installation

1. Install Pygame:
   ```
   pip install pygame
   ```

## How to Run

1. Navigate to the project directory
2. Activate the virtual environment (if using one):
   ```
   # On Windows
   .venv\Scripts\activate
   ```
3. Run the game:
   ```
   python ludo.py
   ```

## Gameplay

- Click the "Roll" button to roll the dice
- Click on your piece to move it if it can move the rolled number
- Get all 4 pieces to the center to win
- Roll a 6 to bring a piece out of home
- Land on an opponent's piece to send it back home

## Controls

- Mouse click on "Roll" button to roll dice
- Mouse click on pieces to select and move them

Enjoy the game!